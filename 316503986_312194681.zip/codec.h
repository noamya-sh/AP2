#ifndef __CODEC__
#define __CODEC__

void encrypt(char *s,int key);
void decrypt(char *s,int key);

#endif
